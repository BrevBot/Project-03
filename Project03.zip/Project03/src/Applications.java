import java.util.Scanner;
import javax.swing.JOptionPane;
import java.util.Random;
public class Applications {
	/*
	 * Brevin Blalock 
	 * CS 160 – 02/03/04, Spring Semester 2019
	 * Project 3: At the ATM Machine
	 *
	 * Description. <Summarize the purpose of the class here.>
	 *
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Account acc = new Account();
		ATM atm = new ATM();
		
		
		
		
		
	}
}

	  class Account {
		 
		 int pin;
		 double balance;
		 String title = "Client Window";
		 
		public void createPin() {
			
			
			
			Random randomNumbers = new Random();
			
			pin = randomNumbers.nextInt(9999)+0;
			
			
		}
		
		public int getPin() {
			
			return pin;
		}
		
		public void setBalance() {
			
			
			
		}
		
		public void showBalance() {
			
			JOptionPane.showMessageDialog(null, "Your current balance is " + balance);
			
		}
		
		public void deposit() {
			
		}
		
		public void withdraw(String withDraw) {
			
		}
		
		public Account() {
			
			createPin();
			
			JOptionPane.showMessageDialog(null, "Take not of your PIN:\n" + pin);
				
			
		}
	 }
	  
	  class ATM {
		  
		  String fig5;
		  
		  Account acc = new Account();
		  
		  public ATM() {
			  
		  }
		  
		  public void transaction() {
			 
			
			String pinCheck = null;
			int Pinchek = Integer.parseInt(pinCheck);
			  
			fig5 = JOptionPane.showInputDialog("Please enter W or w to withdraw\nEnter D or d for deposit");
			
			Scanner keyboard = new Scanner(System.in);
			
			//IF statement for a withdrawl 
			if (fig5.equals("W") || fig5.equals("w")) {
				
			//Displays figure 7
			System.out.println("Please enter your PIN code here:");
			pinCheck = keyboard.nextLine();
			
				if (acc.getPin() == Pinchek) {
					String withDraw = JOptionPane.showInputDialog("Please Enter the amount you want to withdraw");
					
					acc.withdraw(withDraw);
					acc.showBalance();
				} else {
					System.out.println("Wrong PIN, transaction aborted");
				}
			}
			
			//IF statement for a deposit
			if (fig5.equals("D") || fig5.equals("d")) {
				
				//Displays figure 11
				JOptionPane.showMessageDialog(null, "We accept the following dollar bills:\n"
						+ "1, 5, 10, 20, 50, 100\n"
						+ "Please insert the bill on the console\n"
						+ "Enter any other number to stop depositing");
				
				
				
			}
					
			
		  }
	  }
	
